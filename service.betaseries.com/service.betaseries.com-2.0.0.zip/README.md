BetaSeries sync for Kodi
==========================

Automatically update your Betaseries account from Kodi.
Watching UnWatch or just added a movie or a TV episode and this add-on will update automatically into your betasseries account


Thanks a lot to PCCV for the work they done : https://github.com/PCCV/xbmc-betaseries
